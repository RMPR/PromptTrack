# Set the input
number = 5

# Multiply by two
result = number * 2

# Display the result
print(result)