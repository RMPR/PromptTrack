from .mdetr_tracking import PromptTracker
from .object_detection import get_inference